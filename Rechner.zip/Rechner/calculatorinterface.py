import subprocess
import tkinter as tk
from tkinter import ttk

def calculate_with_cpp(num1, operator, num2):
    cpp_executable_path = "Rechner/calculator.exe"
    cpp_input = f"{num1}\n{operator}\n{num2}\n"

    # Den C++-Code kompilieren
    subprocess.run(["g++", "-o", cpp_executable_path, "Rechner/calculator.cpp"])

    # C++-Code ausführen und das Ergebnis abrufen
    result_from_cpp = subprocess.check_output([cpp_executable_path], input=cpp_input, text=True)

    return float(result_from_cpp.strip())  # Entfernen eventueller Leerzeichen am Anfang und Ende

def calculate_button_click():
    num1 = float(entry_num1.get())
    operator = selected_operator.get()
    num2 = float(entry_num2.get())

    result = calculate_with_cpp(num1, operator, num2)
    ans.set(result)
    result_label.config(text=f"Ergebnis: {result}")

def ans_button_click():
    entry_num1.delete(0, tk.END)
    entry_num1.insert(0, ans.get())

# GUI erstellen
root = tk.Tk()
root.title("C++ Rechner")

# Variablen für die Radiobuttons und ANS
selected_operator = tk.StringVar()
ans = tk.DoubleVar()


# Widgets erstellen
label_num1 = ttk.Label(root, text="Gib die erste Zahl ein:")
entry_num1 = ttk.Entry(root)

label_operator = ttk.Label(root, text="Wähle die Rechenoperation:")
addition_button = ttk.Radiobutton(root, text="+", variable=selected_operator, value="+")
subtraction_button = ttk.Radiobutton(root, text="-", variable=selected_operator, value="-")
multiplication_button = ttk.Radiobutton(root, text="*", variable=selected_operator, value="*")
division_button = ttk.Radiobutton(root, text="/", variable=selected_operator, value="/")

label_num2 = ttk.Label(root, text="Gib die zweite Zahl ein:")
entry_num2 = ttk.Entry(root)

calculate_button = ttk.Button(root, text="Berechnen", command=calculate_button_click)
result_label = ttk.Label(root, text="Ergebnis: ")

ans_button = ttk.Button(root, text="ANS", command=ans_button_click)

# Widgets platzieren
label_num1.grid(row=0, column=0, padx=5, pady=5)
entry_num1.grid(row=0, column=1, padx=5, pady=5)

label_operator.grid(row=1, column=0, padx=5, pady=5)
addition_button.grid(row=1, column=1, padx=5, pady=5)
subtraction_button.grid(row=1, column=2, padx=5, pady=5)
multiplication_button.grid(row=1, column=3, padx=5, pady=5)
division_button.grid(row=1, column=4, padx=5, pady=5)

label_num2.grid(row=2, column=0, padx=5, pady=5)
entry_num2.grid(row=2, column=1, padx=5, pady=5)

calculate_button.grid(row=3, column=0, columnspan=5, pady=10)
result_label.grid(row=4, column=0, columnspan=5, pady=5)

ans_button.grid(row=4, column=2, columnspan=5, pady=5)
log.grid(row=5, column=0, columnspan=5, pady=5)

# GUI starten
root.mainloop()
