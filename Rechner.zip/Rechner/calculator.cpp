#include <iostream>

int main() {
    float num1, num2, result;
    char op;

    // Zahlen und Operator von der Standardeingabe lesen
    std::cin >> num1 >> op >> num2;

    switch (op) {
        case '+':
            result = num1 + num2;
            break;
        case '-':
            result = num1 - num2;
            break;
        case '*':
            result = num1 * num2;
            break;
        case '/':
            if (num2 != 0) {
                result = num1 / num2;
            } else {
                std::cerr << "Error: Division by zero" << std::endl;
                return 1; // Exit with an error code
            }
            break;
        default:
            std::cerr << "Invalid operator" << std::endl;
            return 1; // Exit with an error code
    }

    // Ergebnis zur Standardausgabe ausgeben
    std::cout << result << std::endl;

    return 0; // Exit successfully
}
